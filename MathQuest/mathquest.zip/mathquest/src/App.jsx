import { useState, useCallback } from "react";

// ─── QUESTION GENERATORS ──────────────────────────────────────────────────────
const r = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const shuffle = (arr) => [...arr].sort(() => Math.random() - 0.5);

function makeWrongAnswers(correct, count = 3, spread = 5) {
  const wrongs = new Set();
  let attempts = 0;
  while (wrongs.size < count && attempts < 100) {
    attempts++;
    const delta = r(1, spread) * (Math.random() > 0.5 ? 1 : -1);
    const v = correct + delta;
    if (v !== correct && v >= 0 && v <= 9999) wrongs.add(v);
  }
  // Fallback: if not enough, add sequential
  let fallback = correct + spread + 1;
  while (wrongs.size < count) { wrongs.add(fallback++); }
  return [...wrongs];
}

function shuffleAnswers(correct, wrongs) {
  const all = [{ v: String(correct), correct: true }, ...wrongs.map(w => ({ v: String(w), correct: false }))];
  const shuffled = shuffle(all);
  return { answers: shuffled.map(a => a.v), correctIdx: shuffled.findIndex(a => a.correct) };
}

// ─── CURRICULUM GENERATORS ───────────────────────────────────────────────────
// Every generator returns: { q, answers, correct, hint, edu }
const GENERATORS = {

  // ── 1. RAZRED ──────────────────────────────────────────────────────────────
  "1_brojevi20": () => {
    const t = r(0,9);
    const tpl = [
      () => { const a=r(1,18);
        const {answers,correctIdx}=shuffleAnswers(a+1,[a,a+2,a-1].filter(x=>x>=0&&x<=20));
        return {q:`Koji broj dolazi POSLIJE broja ${a}?`,correct:correctIdx,answers,
          hint:`Broji naprijed: ..., ${a}, ___`,
          edu:`🔢 Na brojevnoj crti svaki sljedeći broj je veći za 1. Poslije ${a} dolazi ${a+1}.`}; },
      () => { const a=r(1,9),b=r(1,9-a); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`Koliko je ${a} + ${b}?`,correct:correctIdx,answers,
          hint:`Zamisli ${a} jabuka pa dodaj još ${b}.`,
          edu:`➕ Zbrajanje = spajanje dviju skupina. Trik: dopuni do 10 pa dodaj ostatak. ${a}+${b}=${res}.`}; },
      () => { const a=r(11,19),b=r(1,a-1);
        return {q:`Koji je broj VEĆI: ${a} ili ${b}?`,correct:0,answers:[String(a),String(b),"Isti su","Ne znam"],
          hint:`${a} je dalje desno na brojevnoj crti!`,
          edu:`📏 Na brojevnoj crti: što je broj više desno, to je VEĆI. ${a} > ${b} jer je ${a} dalje od nule.`}; },
      () => { const d=r(1,1),u=r(0,9); const res=d*10+u;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`Koliko je 10 + ${u}?`,correct:correctIdx,answers,
          hint:`10 + ${u}: jedna desetica i ${u} jedinica.`,
          edu:`🔟 Broj 10 je jedna desetica. 10+${u} = ${res}. Npr. 10+5=15, 10+7=17.`}; },
      () => { const start=r(1,14),gap=r(1,3);
        return {q:`Koji broj nedostaje? ${start}, ${start+gap}, __, ${start+gap*3}`,
          correct:1,answers:[String(start+gap*2+1),String(start+gap*2),String(start-1),String(start+gap*3+1)],
          hint:`Razlika između svaka dva broja je ${gap}!`,
          edu:`🔢 Niz brojeva: svaki broj raste za isti iznos (ovdje +${gap}). Pronađi uzorak pa popuni prazninu.`}; },
      () => { const a=r(2,9),b=r(2,9);
        return {q:`Marica ima ${a} jabuka, a Ivica ${b}. Koliko jabuka imaju ukupno?`,
          correct:0,answers:[String(a+b),String(a*b),String(Math.abs(a-b)),String(a+b+1)],
          hint:`"Ukupno" znači ZBROJITI: ${a} + ${b}`,
          edu:`➕ Ključna riječ "ukupno" uvijek znači zbrajanje! Zbroji sve zajedno: ${a}+${b}=${a+b}.`}; },
      () => { const tot=r(5,15),gone=r(1,tot-1); const res=tot-gone;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`U košari je ${tot} jabuka. Mama uzme ${gone}. Koliko ostane?`,correct:correctIdx,answers,
          hint:`"Uzme" znači ODUZETI: ${tot} - ${gone}`,
          edu:`➖ Ključna riječ "uzme", "pojede", "ode" uvijek znači oduzimanje! ${tot}-${gone}=${res}.`}; },
      () => { const a=r(10,18),b=r(1,a-10+1);
        const res=a-b; const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`${a} - ${b} = ?`,correct:correctIdx,answers,
          hint:`Oduzmi: ${a}-${b}. Idi korak po korak!`,
          edu:`➖ Oduzimanje s brojevima do 20: trik je oduzeti do 10 pa nastaviti. ${a}-${b}=${res}.`}; },
      () => { const a=r(1,9);
        return {q:`Koji je broj MANJI: ${a} ili ${a+r(1,5)}?`,
          correct:0,answers:[String(a),String(a+r(1,5)),"Isti su","Ne znam"],
          hint:`Manji broj je bliže nuli na brojevnoj crti.`,
          edu:`📏 Manji broj = bliže nuli. Veći broj = dalje od nule. ${a} < ${a+1} jer je ${a} bliže nuli.`}; },
      () => { const a=r(1,8),b=r(1,8),c=r(1,4); const res=a+b+c;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} + ${b} + ${c} = ?`,correct:correctIdx,answers,
          hint:`Najprije zbroji prva dva: ${a}+${b}=${a+b}, pa dodaj ${c}.`,
          edu:`➕ Tri broja zbrajamo redom: najprije prva dva pa treći. Ili pronađi par koji daje 10!`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "1_zbrajanje": () => {
    const names = [["Ana","Marko"],["Luka","Sara"],["Petra","Ivan"],["Maja","Tomo"],["Iva","Filip"]];
    const [n1,n2] = names[r(0,names.length-1)];
    const fruits = ["jabuka","krušaka","šljiva","trešanja","naranči"];
    const fruit = fruits[r(0,fruits.length-1)];
    const tpl = [
      () => { const a=r(1,9),b=r(1,9); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} + ${b} = ?`,correct:correctIdx,answers,
          hint:`Dopuni ${Math.max(a,b)} do 10: treba još ${10-Math.max(a,b)}.`,
          edu:`➕ Trik za zbrajanje: veći broj dopuni do 10, ostatak dodaj. ${Math.max(a,b)}+${10-Math.max(a,b)}=10, pa +${Math.min(a,b)-(10-Math.max(a,b))>0?Math.min(a,b)-(10-Math.max(a,b)):0}.`}; },
      () => { const a=r(2,9); const res=a*2;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`${a} + ${a} = ?`,correct:correctIdx,answers,
          hint:`Isti broj dva puta — to je dvaput ${a}!`,
          edu:`➕ Zbrajanje istog broja = udvostručavanje. ${a}+${a}=${res}. Ovo je i osnova množenja!`}; },
      () => { const a=r(3,8),b=r(3,8); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${n1} ima ${a} ${fruit}, ${n2} ima ${b} ${fruit}. Koliko ${fruit} imaju zajedno?`,correct:correctIdx,answers,
          hint:`Zajedno = zbrojiti: ${a} + ${b}`,
          edu:`➕ "Zajedno", "ukupno", "sve skupa" = ZBRAJANJE. Uvijek spajamo dvije skupine u jednu.`}; },
      () => { const a=r(5,9),b=r(1,5); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`U autobusu je ${a} putnika. Na stanici uđe još ${b}. Koliko putnika ima sada?`,correct:correctIdx,answers,
          hint:`"Uđe još" = dodaj = zbrojiti: ${a}+${b}`,
          edu:`➕ "Uđe", "dođe još", "donese" = zbrajamo! Bilo je ${a}, dodali smo ${b}, sada je ${res}.`}; },
      () => { const a=r(4,8),b=r(2,5); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`Na livadi pase ${a} krava i ${b} ovaca. Koliko životinja ima ukupno?`,correct:correctIdx,answers,
          hint:`Krave + ovce = ukupno: ${a}+${b}`,
          edu:`➕ Kada pitamo "koliko ukupno" trebamo zbrojiti sve vrste zajedno: ${a}+${b}=${res}.`}; },
      () => { const a=r(6,9),b=r(1,4); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`${a} + ${b} = ?`,correct:correctIdx,answers,
          hint:`${a} treba još ${10-a} do 10. Od ${b} uzmi ${10-a}, ostaje ${b-(10-a)}.`,
          edu:`➕ Prelaz kroz 10: ${a}+${10-a}=10, pa ${10}+${b-(10-a)}=${res}. Korak po korak!`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "1_oduzimanje": () => {
    const tpl = [
      () => { const a=r(10,20),b=r(1,a-1); const res=a-b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} - ${b} = ?`,correct:correctIdx,answers,
          hint:`${a}-${b}: najprije oduzmi do 10, pa ostatak.`,
          edu:`➖ Trik: ${a}-${a-10}=10, pa još -${b-(a-10)}. Ili broji unatrag ${b} koraka od ${a}.`}; },
      () => { const tot=r(8,15),gone=r(1,tot-1); const res=tot-gone;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`Na grani sjedi ${tot} ptica. ${gone} odlete. Koliko ostane?`,correct:correctIdx,answers,
          hint:`"Odlete" = oduzeti: ${tot} - ${gone}`,
          edu:`➖ "Odlete", "pobjegne", "izgubi" = oduzimanje. Ostalo = početni broj − onaj koji je otišao.`}; },
      () => { const a=r(12,20),b=r(3,8); const res=a-b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`Imam ${a} kuna. Potrošim ${b} kune. Koliko mi ostane?`,correct:correctIdx,answers,
          hint:`"Potrošim" = oduzeti: ${a} - ${b}`,
          edu:`➖ Potrošiti novac = oduzimanje. Imali smo ${a}, potrošili ${b}, ostalo je ${res}.`}; },
      () => { const tot=r(10,18),gone=r(2,6); const res=tot-gone;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`U vrećici je ${tot} bombona. Pojedem ${gone}. Koliko ostane?`,correct:correctIdx,answers,
          hint:`Pojedem = oduzimam: ${tot}-${gone}`,
          edu:`➖ Oduzimanje = uzimamo dio od cjeline. Cjelina: ${tot}, uzeto: ${gone}, ostalo: ${res}.`}; },
      () => { const a=r(15,20),b=r(6,a-1); const res=a-b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`${a} - ${b} = ?`,correct:correctIdx,answers,
          hint:`${a}-${b}: idi do 10 (oduzmi ${a-10}), pa još ${b-(a-10)}.`,
          edu:`➖ Prelaz kroz 10: ${a}-${a-10}=10, pa 10-${b-(a-10)}=${res}. Uvijek je lakše proći kroz 10!`}; },
      () => { const tot=r(14,20),gone=r(4,9); const res=tot-gone;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,2));
        return {q:`Knjiga ima ${tot} stranica. Pročitam ${gone}. Koliko stranica ostaje?`,correct:correctIdx,answers,
          hint:`Ostaje = ukupno − pročitano: ${tot}−${gone}`,
          edu:`➖ "Koliko ostaje?" = oduzimanje. Ukupno minus potrošeno/pročitano/pojede = ostatak.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "1_oblici": () => {
    const qs = [
      {q:"Koliko stranica ima trokut?",answers:["4","2","3","5"],correct:2,hint:"Tri-kut → TRI!",edu:"🔷 TROKUT: 3 stranice, 3 kuta. 'Tri' je u samom imenu! Npr. trokut izgleda kao šator."},
      {q:"Koji lik NEMA kutova?",answers:["Kvadrat","Trokut","Krug","Pravokutnik"],correct:2,hint:"Okrugao lik — nema oštrih uglova.",edu:"🔵 KRUG: nema stranica ni kutova, savršeno je okrugao. Npr. kotač, sunce, novčić."},
      {q:"Koliko stranica ima kvadrat?",answers:["3","5","6","4"],correct:3,hint:"Kvadrat = 4 jednake stranice!",edu:"🟦 KVADRAT: 4 jednake stranice i 4 prava kuta. Svaki kut je 90°. Npr. šahovsko polje."},
      {q:"Koji lik izgleda kao kotač?",answers:["Trokut","Krug","Kvadrat","Pravokutnik"],correct:1,hint:"Okruglo i bez kutova...",edu:"🔵 KRUG je jedini lik bez kutova i ravnih stranica. Kotač, tanjur i sunce su krugovi."},
      {q:"Pravokutnik ima koliko stranica?",answers:["3","5","4","6"],correct:2,hint:"Pravokutnik izgleda kao vrata ili prozor!",edu:"🟩 PRAVOKUTNIK: 4 stranice (2 dulje, 2 kraće) i 4 prava kuta. Razlika od kvadrata: stranice nisu jednake."},
      {q:"Koji lik ima 3 kuta?",answers:["Krug","Kvadrat","Trokut","Pravokutnik"],correct:2,hint:"Tri-kut → 3 kuta!",edu:"🔺 TROKUT ima točno 3 kuta i 3 stranice. Može biti šiljast, tup ili pravokutan."},
      {q:"Kvadrat i pravokutnik — koja je razlika?",answers:["Kvadrat ima 3 stranice","U kvadratu su sve stranice jednako duge","Pravokutnik nema kutova","Nema razlike"],correct:1,hint:"Kvadrat = SVE stranice jednake!",edu:"🟦🟩 Kvadrat: sve 4 stranice jednako duge. Pravokutnik: 2 dulje + 2 kraće. Svaki kvadrat je pravokutnik, ali ne obrnuto!"},
      {q:"Koliko kutova ima trokut?",answers:["2","4","3","5"],correct:2,hint:"Tri-KUT → koliko kutova?",edu:"🔺 TROKUT: uvijek 3 kuta (otuda ime!) i 3 stranice. Zbroj svih kutova trokuta je uvijek 180°."},
      {q:"Koji lik izgleda kao pizza cijela (okrugla)?",answers:["Kvadrat","Pravokutnik","Trokut","Krug"],correct:3,hint:"Okrugla pizza = koji lik?",edu:"🔵 Pizza je krug! A jedan komad pizze izgleda kao... TROKUT! 🍕"},
      {q:"Koliko oštrih kutova ima krug?",answers:["4","2","1","0"],correct:3,hint:"Krug je okrugao — ima li kutova?",edu:"🔵 Krug nema ni jednog kuta ni jedne ravne stranice. Zato se savršeno kotrlja!"},
    ];
    return qs[r(0,qs.length-1)];
  },

  // ── 2. RAZRED ──────────────────────────────────────────────────────────────
  "2_brojevi100": () => {
    const tpl = [
      () => { const d=r(1,9);
        const {answers,correctIdx}=shuffleAnswers(d,[d+1,d+2,d-1].filter(x=>x>0&&x!==d));
        return {q:`Koliko desetica ima broj ${d*10}?`,correct:correctIdx,answers,
          hint:`${d*10} = ${d} desetica i 0 jedinica`,
          edu:`💯 Desetica = 10 jedinica. Broj ${d*10} sastoji se od ${d} desetice/desetica. Kao ${d} torbi s 10 bombona.`}; },
      () => { const d=r(1,9),u=r(1,9); const res=d*10+u;
        const {answers,correctIdx}=shuffleAnswers(res,[res+1,res-1,res+10].filter(x=>x>0&&x<=99&&x!==res));
        return {q:`Koji je broj: ${d} desetica i ${u} jedinica?`,correct:correctIdx,answers,
          hint:`${d} desetica = ${d*10}, dodaj ${u} jedinica`,
          edu:`💯 Broj gradimo: desetice × 10 + jedinice. ${d}×10=${d*10}, pa +${u} = ${res}. Npr. 4 desetice i 7 = 47.`}; },
      () => { const a=r(11,49);
        const {answers,correctIdx}=shuffleAnswers(a+1,[a-1,a+3,a+4]);
        return {q:`Koji broj je između ${a} i ${a+2}?`,correct:correctIdx,answers,
          hint:`${a}, ___, ${a+2} — koji broj dolazi između?`,
          edu:`🔢 Između dva uzastopna broja uvijek je točno jedan broj. Između ${a} i ${a+2} je ${a+1}.`}; },
      () => { const a=r(1,4)*10,maxB=Math.floor((90-a)/10),b=r(1,Math.max(1,maxB))*10; const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,[res+10,res-10,res+20].filter(x=>x>0&&x<=99&&x!==res));
        return {q:`Koliko je ${a} + ${b}?`,correct:correctIdx,answers,
          hint:`Zbroji desetice: ${a/10} + ${b/10} = ${res/10} desetica`,
          edu:`💯 Zbrajanje desetica: brojevi koji završavaju na 0 zbrajamo po deseticama. ${a/10}+${b/10}=${res/10} desetica = ${res}.`}; },
      () => { const a=r(11,88),b=r(1,Math.min(9,99-a)); const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,[res+1,res-1,res+2].filter(x=>x>0&&x<=99&&x!==res));
        return {q:`Koliko je ${a} + ${b}?`,correct:correctIdx,answers,
          hint:`Zbroji jedinice: ${a%10}+${b}=${(a%10)+b}, pa pazi na prenos!`,
          edu:`💯 Zbrajanje: najprije jedinice (${a%10}+${b}), pa desetice. Ako jedinice prelaze 9, prenosiš 1 u desetice.`}; },
      () => { const a=r(10,89),b=r(a+1,Math.min(a+20,99));
        return {q:`Koji je veći: ${a} ili ${b}?`,correct:1,answers:[String(a),String(b),"Isti","Ne znam"],
          hint:`Usporedi prvu (lijevu) znamenku: ${Math.floor(a/10)} ili ${Math.floor(b/10)}?`,
          edu:`💯 Uspoređivanje: gledaj znamenku po znamenku s lijeva. Veća prva znamenka = veći broj. Ako su iste, gledaj drugu.`}; },
      () => { const a=r(20,80),b=r(1,a-1); const res=a-b;
        const {answers,correctIdx}=shuffleAnswers(res,[res+1,res-1,res+10].filter(x=>x>0&&x!==res));
        return {q:`${a} - ${b} = ?`,correct:correctIdx,answers,
          hint:`Oduzmi: ${a}-${b}. Pazi na prenos!`,
          edu:`💯 Oduzimanje dvoznamenkastih: kreni od jedinica (${a%10}-${b%10}). Ako ne možeš, posudi deseticu!`}; },
      () => { const shop=r(20,60),price=r(5,shop-5); const rest=shop-price;
        const {answers,correctIdx}=shuffleAnswers(rest,[rest+1,rest-1,rest+5].filter(x=>x>0&&x!==rest));
        return {q:`Imam ${shop} kuna. Kupim igračku za ${price} kuna. Koliko mi ostane?`,correct:correctIdx,answers,
          hint:`Ostalo = imao − potrošio: ${shop}−${price}`,
          edu:`💯 Tekstualni zadatak: "ostane" = oduzimanje. Imao sam ${shop}, potrošio ${price}, ostalo ${rest}.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "2_mnozenje": () => {
    const tpl = [
      () => { const a=r(2,5),b=r(2,9); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${a} × ${b} = ?`,correct:correctIdx,answers,
          hint:`${b} puta po ${a}: ${Array.from({length:b},(_,i)=>a*(i+1)).join(", ")}`,
          edu:`✖️ Množenje = brzo zbrajanje jednakih skupina. ${a}×${b} = zbrajanje ${b} puta broja ${a} = ${res}.`}; },
      () => { const a=r(2,5),b=r(2,6); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`U ${b} košara je po ${a} jabuke. Koliko jabuka ukupno?`,correct:correctIdx,answers,
          hint:`${b} košara × ${a} jabuke = ?`,
          edu:`✖️ Jednake grupe = množenje. ${b} košara s po ${a} jabuke = ${b}×${a} = ${res} jabuka ukupno.`}; },
      () => { const a=r(2,4),b=r(3,7); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`Učionica ima ${a} reda s po ${b} klupa. Koliko klupa ima ukupno?`,correct:correctIdx,answers,
          hint:`Redovi × klupe po redu: ${a}×${b}`,
          edu:`✖️ Redovi i stupci = množenje! ${a} reda po ${b} klupa = ${a}×${b} = ${res} klupa. Zamisli tablicu!`}; },
      () => { const a=r(2,5),b=r(2,8); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${b} djece dobije po ${a} bombone. Koliko bombona ima ukupno?`,correct:correctIdx,answers,
          hint:`${b} djece × ${a} bombona = ?`,
          edu:`✖️ "Po ${a} za svako od ${b}" = množenje. Svako dijete = ista količina → množimo!`}; },
      () => { const a=r(2,5),b=r(2,6); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${a} × ${b} = ?`,correct:correctIdx,answers,
          hint:`Broji po ${a}: ${Array.from({length:b},(_,i)=>a*(i+1)).join(", ")}`,
          edu:`✖️ Tablica množenja: znati tablicu napametu ubrzava računanje. ${a}×${b} = ${res}. Provjeri: ${b}×${a} = ${res} isto!`}; },
      () => { const a=r(2,5); const res=a*10;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,5));
        return {q:`${a} × 10 = ?`,correct:correctIdx,answers,
          hint:`Množenje s 10: dodaj nulu iza broja!`,
          edu:`✖️ Trik za ×10: samo dodaj nulu! ${a}×10=${res}. To je ${a} desetica = ${res}. Lako!`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "2_dijeljenje": () => {
    const tpl = [
      () => { const b=r(2,5),res=r(2,9); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} ÷ ${b} = ?`,correct:correctIdx,answers,
          hint:`Koji broj × ${b} = ${a}?`,
          edu:`➗ Dijeljenje = raspodjela u jednake grupe. ${a}÷${b}: pitaj se koji broj × ${b} = ${a}? → ${res}.`}; },
      () => { const b=r(2,5),res=r(2,8); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} bombona podijeli jednako na ${b} djece. Koliko svako dobije?`,correct:correctIdx,answers,
          hint:`${a} ÷ ${b} = ?`,
          edu:`➗ Jednaka raspodjela = dijeljenje. ${a} bombona za ${b} djece: svako dobije ${a}÷${b}=${res} bombona.`}; },
      () => { const b=r(2,4),res=r(3,8); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} jabuka slažemo u košare po ${b}. Koliko košara trebamo?`,correct:correctIdx,answers,
          hint:`${a} ÷ ${b} = ?`,
          edu:`➗ Dijeljenje nam govori koliko grupa možemo napraviti. ${a}÷${b}=${res} košara.`}; },
      () => { const b=r(2,5),res=r(2,7); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`Mama reže ${a} kolačića na ${b} jednaka dijela. Koliko dijelova ima svaki?`,correct:correctIdx,answers,
          hint:`${a} ÷ ${b} = ?`,
          edu:`➗ Dijeljenje = rezanje na jednake dijelove. ${a}÷${b}=${res}. Provjeri: ${res}×${b}=${a} ✓`}; },
      () => { const b=r(2,5),res=r(2,9); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,3));
        return {q:`${a} ÷ ${b} = ?`,correct:correctIdx,answers,
          hint:`Dijeljenje je obrnuto od množenja: ${b} × ? = ${a}`,
          edu:`➗ Veza množenja i dijeljenja: ako ${res}×${b}=${a}, onda ${a}÷${b}=${res}. Uvijek provjeri množenjem!`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "2_mjerenje": () => {
    const tpl = [
      {q:"Koliko centimetara ima 1 metar?",answers:["10","1000","100","50"],correct:2,
        hint:"1 m = ___ cm",edu:"📏 1 metar (m) = 100 centimetara (cm). Ravnalo u školi je obično 30 cm, a metar je kao 3 i trećina takvih ravnala."},
      {q:"Što je teže: 1 kilogram ili 500 grama?",answers:["500 grama","1 kilogram","Isto","Ne znam"],correct:1,
        hint:"1 kg = 1000 grama",edu:"⚖️ 1 kilogram (kg) = 1000 grama (g). 500 g je pola kilograma. Npr. pakiranje šećera obično je 1 kg."},
      {q:"Koliko minuta ima 1 sat?",answers:["30","100","60","24"],correct:2,
        hint:"Minutna kazaljka napravi jedan pun krug za 60 minuta",edu:"🕐 1 sat = 60 minuta. Kratka kazaljka = sati, duga = minute. Kada duga kazaljka obiđe krug = prošao je 1 sat."},
      {q:"Koliko sati ima jedan dan?",answers:["12","48","24","60"],correct:2,
        hint:"Dan ima noć i dan — svaki po 12 sati",edu:"🌅 1 dan = 24 sata (12 prijepodne + 12 poslijepodne). Sat je kratica 'h' (od latinskog 'hora')."},
      () => { const h=r(1,10),add=r(1,5); const res=h+add;
        return {q:`Ako je sada ${h}:00, koliko će biti za ${add} sata?`,
          answers:[String(res-1),String(res+1),String(res),String(res+2)],correct:2,
          hint:`${h} + ${add} = ?`,
          edu:`🕐 Zbrajamo sate kao obične brojeve (do 24). ${h}+${add}=${res}. Ako prijeđe 24, oduzimamo 24 (novi dan).`}; },
      () => { const cm=r(101,190); const leftcm=cm-100;
        return {q:`${cm} cm je jednako koliko metara i centimetara?`,
          answers:[`2 m ${leftcm} cm`,`1 m ${leftcm} cm`,`1 m ${leftcm+10} cm`,`0 m ${cm} cm`],correct:1,
          hint:`${cm} cm = 100 cm + ${leftcm} cm = 1 m + ${leftcm} cm`,
          edu:`📏 Pretvaranje: 100 cm = 1 m. ${cm}cm = 1m + ${leftcm}cm. Kao što je 150 lipa = 1 kuna + 50 lipa.`}; },
      () => { const kg=r(1,5),g=r(100,900); const tot=kg*1000+g;
        return {q:`${kg} kg i ${g} g je ukupno koliko grama?`,
          answers:[String(tot+100),String(tot),String(tot-100),String(tot+10)],correct:1,
          hint:`${kg} kg = ${kg*1000} g, pa dodaj ${g} g`,
          edu:`⚖️ Pretvaranje kg u g: pomnoži s 1000. ${kg}kg = ${kg*1000}g. Pa ${kg*1000}+${g}=${tot}g ukupno.`}; },
    ];
    const t=tpl[r(0,tpl.length-1)];
    return typeof t==="function"?t():t;
  },

  // ── 3. RAZRED ──────────────────────────────────────────────────────────────
  "3_brojevi1000": () => {
    const tpl = [
      () => { const s=r(1,9);
        const {answers,correctIdx}=shuffleAnswers(s,[s*10,s+1,s-1||1]);
        return {q:`Koliko stotica ima broj ${s*100}?`,correct:correctIdx,answers,
          hint:`${s*100} = ${s} stotica i 0 desetica i 0 jedinica`,
          edu:`🔢 Stotica = 100 jedinica = 10 desetica. ${s*100} ima ${s} stotica. Kao ${s} kutija s 100 predmeta.`}; },
      () => { const s=r(1,9),d=r(0,9),u=r(0,9); const res=s*100+d*10+u;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,15));
        return {q:`Koji je broj: ${s} stotica, ${d} desetica, ${u} jedinica?`,correct:correctIdx,answers,
          hint:`${s}×100 + ${d}×10 + ${u} = ?`,
          edu:`🔢 Troznamenkasti broj: stotice (×100) + desetice (×10) + jedinice. Npr. 357 = 300+50+7.`}; },
      () => { const s=r(1,8),d=r(1,9),u=r(1,9); const res=s*100+d*10+u;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,15));
        return {q:`Koliko je ${s*100} + ${d*10} + ${u}?`,correct:correctIdx,answers,
          hint:`Zbroji stotice, desetice i jedinice: ${s*100}+${d*10}+${u}`,
          edu:`🔢 Rastavljanje broja: ${res} = ${s*100} (stotice) + ${d*10} (desetice) + ${u} (jedinice). Koristi to za lakše računanje.`}; },
      () => { const a=r(100,850),diff=r(10,100); const b=a+diff;
        return {q:`Koji je veći: ${a} ili ${b}?`,correct:1,answers:[String(a),String(b),"Isti","Ne znam"],
          hint:`Usporedi prvu znamenku: ${Math.floor(a/100)} ili ${Math.floor(b/100)}?`,
          edu:`🔢 Uspoređivanje troznamenkastih: gledaj stotice, pa desetice, pa jedinice. Veća prva znamenka = veći broj.`}; },
      () => { const a=r(1,4)*100,b=r(1,4)*100; const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,50));
        return {q:`Koliko je ${a} + ${b}?`,correct:correctIdx,answers,
          hint:`${a/100} stotica + ${b/100} stotica = ${res/100} stotica`,
          edu:`🔢 Zbrajanje stotica: ${a}+${b}=${res}. Kao zbrajanje desetica, samo 10× veće.`}; },
      () => { const ppl=r(200,800),more=r(50,200); const res=ppl+more;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,30));
        return {q:`U gradu živi ${ppl} ljudi. Doseli se još ${more}. Koliko ih ima sada?`,correct:correctIdx,answers,
          hint:`"Doseli još" = zbrojiti: ${ppl}+${more}`,
          edu:`🔢 Tekstualni zadatak s velikim brojevima: isti principi! "Doseli se" = zbrajamo. ${ppl}+${more}=${res}.`}; },
      () => { const start=r(300,900),sub=r(50,200); const res=start-sub;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,30));
        return {q:`Knjižnica ima ${start} knjiga. Posudi se ${sub} knjiga. Koliko ostaje?`,correct:correctIdx,answers,
          hint:`Posudi = oduzeti: ${start}-${sub}`,
          edu:`🔢 "Posudi", "proda", "izgubi" = oduzimamo. Ostalo = početak − oduzeto: ${start}-${sub}=${res}.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "3_mnozenje_pisano": () => {
    const tpl = [
      () => { const b=r(2,4),a=r(11,49); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,8));
        return {q:`${a} × ${b} = ?`,correct:correctIdx,answers,
          hint:`Najprije jedinice (${a%10}×${b}=${(a%10)*b}), pa desetice (${Math.floor(a/10)*10}×${b}=${Math.floor(a/10)*b*10})`,
          edu:`📝 Pisano množenje s lijeva: ${a}×${b} → ${b}×${a%10}=${(a%10)*b} (jedinice) + ${b}×${Math.floor(a/10)*10}=${Math.floor(a/10)*b*10} (desetice) = ${res}.`}; },
      () => { const b=r(2,3),a=r(21,49); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,8));
        return {q:`Škola ima ${b} razreda s po ${a} učenika. Koliko učenika ima škola?`,correct:correctIdx,answers,
          hint:`${b} × ${a} = ?`,
          edu:`📝 "Po ${a} u svakom od ${b}" = množenje. ${b}×${a}=${res}. Pisano: ${b}×${a%10}=${b*(a%10)}, ${b}×${Math.floor(a/10)*10}=${b*Math.floor(a/10)*10}.`}; },
      () => { const b=r(2,4),a=r(12,45); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,8));
        return {q:`Autobus napravi ${b} putovanja, svaki put preveze ${a} putnika. Koliko ukupno?`,correct:correctIdx,answers,
          hint:`${b} putovanja × ${a} putnika = ?`,
          edu:`📝 Jednaka putovanja = množenje! ${b}×${a}=${res}. Svaki put isti broj, množimo!`}; },
      () => { const b=r(2,4),a=r(11,39); const res=a*b;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,8));
        return {q:`${a} × ${b} = ?`,correct:correctIdx,answers,
          hint:`Rastavi ${a} = ${Math.floor(a/10)*10} + ${a%10}, pa pomnoži svaki dio.`,
          edu:`📝 Distributivnost: ${a}×${b} = ${Math.floor(a/10)*10}×${b} + ${a%10}×${b} = ${Math.floor(a/10)*b*10} + ${(a%10)*b} = ${res}.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "3_razlomci": () => {
    const tpl = [
      () => { const tot=r(2,20)*2; const half=tot/2;
        const {answers,correctIdx}=shuffleAnswers(half,makeWrongAnswers(half,3,3).filter(x=>x>0));
        return {q:`½ od ${tot} je?`,correct:correctIdx,answers,
          hint:`Podijeli ${tot} na 2 jednaka dijela: ${tot}÷2`,
          edu:`🍕 ½ = polovina = jedan od dva jednaka dijela. Da nađeš ½, dijeli s 2: ${tot}÷2=${half}.`}; },
      () => { const tot=r(1,6)*4; const quarter=tot/4;
        const {answers,correctIdx}=shuffleAnswers(quarter,makeWrongAnswers(quarter,3,2).filter(x=>x>0));
        return {q:`¼ od ${tot} je?`,correct:correctIdx,answers,
          hint:`Podijeli ${tot} na 4 jednaka dijela: ${tot}÷4`,
          edu:`🍕 ¼ = četvrtina = jedan od četiri jednaka dijela. Da nađeš ¼, dijeli s 4: ${tot}÷4=${quarter}.`}; },
      {q:"Pizzu si podijelio na 2 jednaka dijela. Jedan dio je...",answers:["Trećina","Polovina ½","Četvrtina","Cijela"],correct:1,
        hint:"2 jednaka dijela → svaki je pola",edu:"🍕 ½ (polovina) = pizza podijeljena na 2 jednaka dijela. Svaka polovica je isto velika."},
      {q:"Koliko četvrtina (¼) čini jednu cijelu jabuku?",answers:["2","3","4","6"],correct:2,
        hint:"¼ + ¼ + ¼ + ¼ = ?",edu:"🍎 4 četvrtine = 1 cijela. ¼+¼+¼+¼=1. Kao kad jabuku razrežeš na 4 jednaka komada."},
      {q:"Koji je razlomak VEĆI: ½ ili ¼?",answers:["¼","½","Isti su","Ne znam"],correct:1,
        hint:"Pol torte > četvrtina torte",edu:"🍕 Što manji brojnik u nazivniku, to VEĆI dio! ½ > ¼ jer ½ je pola, a ¼ je samo četvrtina."},
      () => { const tot=r(8,20)*2; const half=tot/2;
        return {q:`Mama peče ${tot} keksa. Daje ti polovicu. Koliko keksa dobiš?`,
          correct:0,answers:[String(half),String(half+2),String(half-2),String(tot)],
          hint:`Polovica = ½ = ${tot}÷2`,
          edu:`🍪 "Polovica", "pol", "pola" = ½. Dijeli s 2! ${tot}÷2=${half}. Ostatak je za sutra!`}; },
      {q:"Čokolada ima 8 kockica. Pojedeš ¼. Koliko kockica si pojeo?",answers:["4","3","2","1"],correct:2,
        hint:"¼ od 8 = 8÷4 = ?",edu:"🍫 ¼ od 8: dijeli 8 s 4 = 2 kockice. Ostalo je ¾ = 6 kockica. Provjeri: 2+6=8 ✓"},
    ];
    const t=tpl[r(0,tpl.length-1)];
    return typeof t==="function"?t():t;
  },

  "3_opseg": () => {
    const tpl = [
      () => { const s=r(2,12); const res=4*s;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,6));
        return {q:`Kvadrat ima stranicu ${s} cm. Koliki mu je opseg?`,correct:correctIdx,answers,
          hint:`Kvadrat: 4 jednake stranice → opseg = 4 × ${s}`,
          edu:`📐 Opseg kvadrata = 4 × stranica = 4×${s}=${res} cm. Opseg = ukupna dužina ruba lika.`}; },
      () => { const l=r(3,12),w=r(2,l-1); const res=2*(l+w);
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,6));
        return {q:`Pravokutnik: duljina ${l} cm, širina ${w} cm. Opseg?`,correct:correctIdx,answers,
          hint:`Opseg = 2 × (duljina + širina) = 2 × (${l}+${w})`,
          edu:`📐 Opseg pravokutnika = 2×(d+š) = 2×(${l}+${w}) = 2×${l+w} = ${res} cm. Dva para jednakih stranica!`}; },
      () => { const s=r(2,9)*4; const side=s/4;
        const {answers,correctIdx}=shuffleAnswers(side,makeWrongAnswers(side,3,3));
        return {q:`Opseg kvadrata je ${s} cm. Kolika je jedna stranica?`,correct:correctIdx,answers,
          hint:`Stranica = opseg ÷ 4 = ${s}÷4`,
          edu:`📐 Ako znaš opseg kvadrata, nađi stranicu: stranica = opseg÷4 = ${s}÷4 = ${side} cm.`}; },
      () => { const l=r(3,8),w=r(3,8); const res=2*(l+w);
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,5));
        return {q:`Vrt je ${l} m dug i ${w} m širok. Koliko dugi trebamo plot?`,correct:correctIdx,answers,
          hint:`Plot = opseg = 2×(${l}+${w})`,
          edu:`📐 Plot oko vrta = opseg pravokutnika! 2×(${l}+${w})=2×${l+w}=${res} m plota. Praktična primjena!`}; },
      () => { const a=r(3,6),b=r(3,6),c=r(3,6); const res=a+b+c;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,5));
        return {q:`Trokut ima stranice ${a} cm, ${b} cm i ${c} cm. Opseg?`,correct:correctIdx,answers,
          hint:`Opseg trokuta = zbroj svih 3 stranica: ${a}+${b}+${c}`,
          edu:`📐 Opseg trokuta = ${a}+${b}+${c}=${res} cm. Opseg BILO kojeg lika = zbroj svih stranica!`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  // ── 4. RAZRED ──────────────────────────────────────────────────────────────
  "4_velikibrojevi": () => {
    const tpl = [
      {q:"Kako se čita broj 1.000.000?",answers:["Sto tisuća","Deset tisuća","Milijun","Milijarda"],correct:2,
        hint:"1 pa 6 nula = milijun",edu:"🔢 Milijun = 1.000.000 (šest nula). Tisuća = 1.000 (tri nule). Deset tisuća = 10.000. Sto tisuća = 100.000."},
      () => { const t=r(10,90); const res=t*1000;
        return {q:`Koliko tisuća ima u broju ${res.toLocaleString("hr-HR")}?`,
          correct:1,answers:[String(t*10),String(t),String(t*100),String(t/10)],
          hint:`${res.toLocaleString("hr-HR")} = ${t} tisuća`,
          edu:`🔢 Tisuće: ${res}=${t}×1000. Da nađemo koliko tisuća, dijelimo s 1000. ${res}÷1000=${t} tisuća.`}; },
      () => { const a=r(100,400)*1000,b=r(10,90)*1000; const res=a+b;
        const {answers,correctIdx}=shuffleAnswers(res,[res+1000,res-1000,res+10000].filter(x=>x>0));
        return {q:`Koliko je ${a.toLocaleString("hr-HR")} + ${b.toLocaleString("hr-HR")}?`,
          correct:correctIdx,answers:answers.map(a=>Number(a).toLocaleString("hr-HR")),
          hint:`Zbroji tisuće: ${a/1000}+${b/1000}=${res/1000} tisuća`,
          edu:`🔢 Zbrajanje tisućica: ${a}+${b}=${res}. Isti princip kao zbrajanje desetica ili stotica, samo s tisućicama!`}; },
      () => { const a=r(100000,850000),b=r(1000,50000);
        return {q:`Koji je veći: ${a.toLocaleString("hr-HR")} ili ${(a+b).toLocaleString("hr-HR")}?`,
          correct:1,answers:[a.toLocaleString("hr-HR"),(a+b).toLocaleString("hr-HR"),"Isti","Ne znam"],
          hint:`Usporedi znamenku po znamenku s lijeva!`,
          edu:`🔢 Uspoređivanje velikih brojeva: gledaj s lijeva. ${a+b}>${a} jer ${a+b} ima više tisuća.`}; },
    ];
    const t=tpl[r(0,tpl.length-1)];
    return typeof t==="function"?t():t;
  },

  "4_dijeljenje_pisano": () => {
    const tpl = [
      () => { const b=r(2,6),res=r(10,30); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${a} ÷ ${b} = ?`,correct:correctIdx,answers,
          hint:`Probaj: ${b} × ? = ${a}`,
          edu:`➗ Pisano dijeljenje: ${a}÷${b}. Kreni od lijeve znamenke. ${Math.floor(a/10)}÷${b}=... Pa ostatak s jedinicom.`}; },
      () => { const b=r(2,5),res=r(10,25); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${a} učenika podijelimo u ${b} razreda jednako. Koliko u svakom?`,correct:correctIdx,answers,
          hint:`${a} ÷ ${b} = ?`,
          edu:`➗ "Jednako u ${b} grupa" = dijeljenje s ${b}. ${a}÷${b}=${res}. Provjeri: ${res}×${b}=${a} ✓`}; },
      () => { const b=r(2,6),res=r(12,28); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`Kupimo ${a} jaja u pakiranjima po ${b}. Koliko paketa?`,correct:correctIdx,answers,
          hint:`${a} ÷ ${b} = ?`,
          edu:`➗ "Pakiranje po ${b}" = dijeljenje s ${b}. ${a}÷${b}=${res} paketa. Dijeljenje nam govori koliko jednakih grupa!`}; },
      () => { const b=r(3,6),res=r(10,20); const a=b*res;
        const {answers,correctIdx}=shuffleAnswers(res,makeWrongAnswers(res,3,4));
        return {q:`${a} ÷ ${b} = ?`,correct:correctIdx,answers,
          hint:`Kreni od najveće znamenke: ${Math.floor(a/10/b)*10+Math.floor(a%100/b)} → provjeri`,
          edu:`➗ Korak po korak: ${a}÷${b}. Koliko puta ${b} ide u ${Math.floor(a/10)}? → Nastavi s ostatkom.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "4_decimalni": () => {
    const tpl = [
      () => { const w=r(1,9),d=r(1,9);
        return {q:`Kako se piše '${w} i ${d} desetinki'?`,
          answers:[`${w}${d}`,`${w},0${d}`,`${w},${d}`,`0,${w}${d}`],correct:2,
          hint:`Cijeli dio, zarez, pa desetinke: ${w},${d}`,
          edu:`🔣 Decimalni zarez odvaja cijeli od decimalnog dijela. ${w},${d} = ${w} cijela i ${d} desetinki.`}; },
      () => { const w=r(1,5),d1=r(1,4),d2=r(d1+1,9);
        return {q:`Koji je veći: ${w},${d1} ili ${w},${d2}?`,
          correct:1,answers:[`${w},${d1}`,`${w},${d2}`,"Isti su","Ne znam"],
          hint:`Cijeli isti (${w}), usporedi decimale: ${d1} ili ${d2}?`,
          edu:`🔣 Decimalni brojevi: isti cijeli dio → usporedi decimale. ${d2}>${d1}, pa je ${w},${d2} > ${w},${d1}.`}; },
      () => { const euros=r(1,9),cents=r(10,90);
        return {q:`${euros} eura i ${cents} centi zapisujemo kao?`,
          answers:[`${euros}${cents}`,`${euros},${cents} €`,`0,${euros}${cents} €`,`${euros*100} €`],correct:1,
          hint:`${euros} € i ${cents} ct = ${euros},${cents} €`,
          edu:`💶 Euro i centi: 1 € = 100 centi. ${euros},${cents} € = ${euros} eura i ${cents} centi. Decimalni zarez dijeli eure od centi!`}; },
      () => { const a=r(2,5),b=r(1,3); const res=a+b;
        return {q:`${a},5 + ${b},5 = ?`,
          correct:1,answers:[`${res},10`,String(res+1),`${res},5`,`${res-1},0`],
          hint:`${a}+${b}=${res}, a 0,5+0,5=1,0`,
          edu:`🔣 Zbrajanje decimala: najprije cijele (${a}+${b}=${res}), pa decimale (0,5+0,5=1,0). Ukupno ${res+1},0.`}; },
      () => { const a=(r(20,59)/10).toFixed(1), b=(r(10,19)/10).toFixed(1);
        const res=(parseFloat(a)-parseFloat(b)).toFixed(1);
        return {q:`${a} - ${b} = ?`,correct:0,
          answers:[res,`${parseFloat(res)+0.1}`,`${parseFloat(res)+0.2}`,`${parseFloat(res)-0.1}`].map(String),
          hint:`Oduzmi cijele, pa decimale: (${Math.floor(parseFloat(a))}-${Math.floor(parseFloat(b))}) i (${(parseFloat(a)%1).toFixed(1)}−${(parseFloat(b)%1).toFixed(1)})`,
          edu:`🔣 Oduzimanje decimala: poravnaj zareze pa oduzmi kao obične brojeve. ${a}-${b}=${res}.`}; },
    ];
    return tpl[r(0,tpl.length-1)]();
  },

  "4_simetrija": () => {
    const qs = [
      {q:"Koji lik ima os simetrije?",answers:["Nepravilan četverokut","Kvadrat","Nepravilan trokut","Niti jedan"],correct:1,
        hint:"Kvadrat možeš presaviti na pola i oba dijela se poklope!",
        edu:"🦋 Os simetrije: zamislimo presvijanje — obje strane se moraju savršeno poklopiti. Kvadrat ima 4 takve osi."},
      {q:"Koliko osi simetrije ima kvadrat?",answers:["1","2","4","6"],correct:2,
        hint:"Vodoravno, okomito i 2 dijagonale = 4 osi!",
        edu:"🦋 Kvadrat: 4 osi simetrije (2 ravne + 2 dijagonalne). Pravokutnik ima samo 2 (ravne, ne dijagonalne!)."},
      {q:"Os simetrije slova 'A' je...",answers:["Vodoravna","Nema je","Okomita","Dijagonalna"],correct:2,
        hint:"Presaviješ li 'A' po sredini, lijeva i desna strana se poklope!",
        edu:"🦋 Slovo 'A' ima okomitu os simetrije — lijeva i desna strana su ogledalna slika. Koja slova NE? Npr. 'G', 'F'."},
      {q:"Leptir ima os simetrije. Koja?",answers:["Vodoravna","Okomita","Dijagonalna","Nema je"],correct:1,
        hint:"Lijevo i desno krilo su ogledalna slika!",
        edu:"🦋 Leptir: okomita os simetrije. Lijevo i desno krilo su zrcalna slika. Mnoge životinje imaju tu simetriju!"},
      {q:"Koliko osi simetrije ima krug?",answers:["0","1","4","Beskonačno mnogo"],correct:3,
        hint:"Krug možeš presaviti na beskonačno načina!",
        edu:"🦋 Krug ima beskonačno osi simetrije — svaki promjer je os simetrije! Zato je krug 'najsimetričniji' lik."},
      {q:"Koliko osi simetrije ima pravokutnik?",answers:["4","1","3","2"],correct:3,
        hint:"Vodoravno i okomito — dijagonale NISU osi!",
        edu:"🦋 Pravokutnik: samo 2 osi (vodoravna i okomita). Dijagonale pravokutnika NISU osi simetrije — stranice nisu jednake!"},
      {q:"Koje od ovih slova ima os simetrije?",answers:["F","G","H","J"],correct:2,
        hint:"Koje slovo izgleda isto zrcaljeno po sredini?",
        edu:"🦋 Slovo 'H' ima i vodoravnu i okomitu os simetrije! Provjeri ostala: 'F', 'G', 'J' nemaju ni jednu os."},
      {q:"Jednakostranični trokut ima koliko osi simetrije?",answers:["1","2","3","0"],correct:2,
        hint:"Svaka visina jednakokračnog trokuta je os!",
        edu:"🦋 Jednakostranični trokut: 3 osi simetrije (svaka prolazi kroz vrh i polovište nasuprot stranice). Simetrija prati jednakost stranica!"},
    ];
    return qs[r(0,qs.length-1)];
  },
};

const CURRICULUM = {
  1: {
    color:"#FF6B6B",emoji:"🌱",name:"1. razred",
    topics:[
      {id:"1_brojevi20",icon:"🔢",name:"Brojevi do 20",desc:"Čitanje, pisanje i uspoređivanje"},
      {id:"1_zbrajanje",icon:"➕",name:"Zbrajanje do 20",desc:"Zbrajanje s prelazom i bez"},
      {id:"1_oduzimanje",icon:"➖",name:"Oduzimanje do 20",desc:"Oduzimanje s prelazom i bez"},
      {id:"1_oblici",icon:"🔷",name:"Geometrijski oblici",desc:"Trokut, krug, kvadrat, pravokutnik"},
    ]
  },
  2: {
    color:"#FF9F43",emoji:"🌟",name:"2. razred",
    topics:[
      {id:"2_brojevi100",icon:"💯",name:"Brojevi do 100",desc:"Desetice, jedinice, uspoređivanje"},
      {id:"2_mnozenje",icon:"✖️",name:"Množenje — tablice",desc:"Tablice množenja 2-5"},
      {id:"2_dijeljenje",icon:"➗",name:"Dijeljenje — osnove",desc:"Dijeljenje kao suprotnost množenja"},
      {id:"2_mjerenje",icon:"📏",name:"Mjerenje i vrijeme",desc:"Duljina, masa, sat"},
    ]
  },
  3: {
    color:"#FECA57",emoji:"🚀",name:"3. razred",
    topics:[
      {id:"3_brojevi1000",icon:"🔢",name:"Brojevi do 1000",desc:"Stotice, desetice, jedinice"},
      {id:"3_mnozenje_pisano",icon:"📝",name:"Pisano množenje",desc:"Množenje višeznamenkastih"},
      {id:"3_razlomci",icon:"🍕",name:"Razlomci ½ i ¼",desc:"Osnove razlomaka"},
      {id:"3_opseg",icon:"📐",name:"Opseg likova",desc:"Opseg kvadrata i pravokutnika"},
    ]
  },
  4: {
    color:"#48DBFB",emoji:"🌊",name:"4. razred",
    topics:[
      {id:"4_velikibrojevi",icon:"🔢",name:"Veliki brojevi",desc:"Brojevi do milijuna"},
      {id:"4_dijeljenje_pisano",icon:"➗",name:"Pisano dijeljenje",desc:"Dijeljenje s jednoznamenkastim"},
      {id:"4_decimalni",icon:"🔣",name:"Decimalni brojevi",desc:"Desetinke i stotinke"},
      {id:"4_simetrija",icon:"🦋",name:"Simetrija",desc:"Os simetrije i sukladnost"},
    ]
  },
};

const TOTAL_QUESTIONS = 20;

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const STARS_DATA = Array.from({length:50},(_,i)=>({
  id:i,x:Math.random()*100,y:Math.random()*100,
  size:Math.random()*2.5+0.8,delay:Math.random()*4,
}));

function Stars() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {STARS_DATA.map(s=>(
        <div key={s.id} className="absolute rounded-full bg-white"
          style={{left:`${s.x}%`,top:`${s.y}%`,width:s.size,height:s.size,
            opacity:0.25+Math.random()*0.45,
            animation:`twinkle ${2+s.delay}s ease-in-out infinite alternate`}} />
      ))}
    </div>
  );
}

function ProgressBar({value,max,color,h=4}) {
  return (
    <div className="w-full rounded-full overflow-hidden" style={{height:h,background:"rgba(255,255,255,0.1)"}}>
      <div className="h-full rounded-full transition-all duration-700"
        style={{width:`${Math.min(100,(value/max)*100)}%`,background:color}} />
    </div>
  );
}

function Pill({children,color,bg,onClick}) {
  return (
    <span className="px-3 py-1 rounded-full text-xs font-bold cursor-pointer"
      onClick={onClick}
      style={{color,background:bg,fontFamily:"'Nunito',sans-serif"}}>
      {children}
    </span>
  );
}

// Logo / Home link component
function Logo({onClick}) {
  return (
    <button onClick={onClick}
      className="flex items-center gap-2 group transition-all duration-200 hover:opacity-80"
      style={{background:"none",border:"none",cursor:"pointer",padding:0}}>
      <span className="text-2xl" style={{animation:"float 3s ease-in-out infinite"}}>🧮</span>
      <span className="font-black text-lg" style={{
        fontFamily:"'Baloo 2',cursive",
        background:"linear-gradient(90deg,#FECA57,#FF6B6B)",
        WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"
      }}>MathQuest</span>
    </button>
  );
}

// ─── SCREEN: WELCOME ─────────────────────────────────────────────────────────
function WelcomeScreen({onStart}) {
  const [name,setName]=useState("");
  const [selected,setSelected]=useState(null);
  const [nameTouched,setNameTouched]=useState(false);
  const grades=Object.entries(CURRICULUM);
  const nameInvalid = nameTouched && name.trim().length === 0;

  const handleStart = () => {
    setNameTouched(true);
    if (!name.trim()) return;
    if (!selected) return;
    onStart(name.trim(), selected);
  };

  return (
    <div className="flex flex-col items-center gap-6 px-4 py-6">
      <div className="text-center">
        <div className="text-7xl mb-3" style={{filter:"drop-shadow(0 0 30px #FECA57)",animation:"float 3s ease-in-out infinite"}}>🧮</div>
        <h1 className="text-5xl font-black mb-1" style={{fontFamily:"'Baloo 2',cursive",
          background:"linear-gradient(90deg,#FECA57 0%,#FF6B6B 50%,#54A0FF 100%)",
          WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
          MathQuest
        </h1>
        <p className="text-white opacity-60 text-base" style={{fontFamily:"'Nunito',sans-serif"}}>
          Matematika za 1. – 4. razred · HRV kurikulum
        </p>
      </div>

      <div className="w-full max-w-xs">
        <label className="text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1"
          style={{fontFamily:"'Nunito',sans-serif",color: nameInvalid ? "#FF6B6B" : "rgba(255,255,255,0.6)"}}>
          Tvoje ime <span style={{color:"#FF6B6B"}}>*</span>
        </label>
        <input
          value={name}
          onChange={e=>{setName(e.target.value); setNameTouched(true);}}
          onBlur={()=>setNameTouched(true)}
          placeholder="Upiši svoje ime za početak..."
          className="w-full px-4 py-3 rounded-2xl text-white font-bold outline-none text-base transition-all"
          style={{
            background: nameInvalid ? "rgba(255,107,107,0.08)" : "rgba(255,255,255,0.08)",
            border: `1.5px solid ${nameInvalid ? "#FF6B6B" : name.trim() ? "#2ed573" : "rgba(255,255,255,0.15)"}`,
            fontFamily:"'Nunito',sans-serif",
            boxShadow: nameInvalid ? "0 0 12px rgba(255,107,107,0.2)" : name.trim() ? "0 0 12px rgba(46,213,115,0.15)" : "none",
          }} />
        {nameInvalid && (
          <p className="text-xs mt-1.5 font-semibold" style={{color:"#FF6B6B",fontFamily:"'Nunito',sans-serif"}}>
            ⚠️ Ime je obavezno za početak!
          </p>
        )}
      </div>

      <div className="w-full max-w-xs">
        <p className="text-white opacity-60 text-xs font-semibold uppercase tracking-wider mb-3"
          style={{fontFamily:"'Nunito',sans-serif"}}>Odaberi razred</p>
        <div className="grid grid-cols-2 gap-3">
          {grades.map(([g,data])=>(
            <button key={g} onClick={()=>setSelected(Number(g))}
              className="flex flex-col items-center gap-2 rounded-2xl py-5 transition-all duration-200"
              style={{
                background:selected===Number(g)?`${data.color}25`:"rgba(255,255,255,0.06)",
                border:`2px solid ${selected===Number(g)?data.color:"rgba(255,255,255,0.1)"}`,
                transform:selected===Number(g)?"scale(1.04)":"scale(1)",
                boxShadow:selected===Number(g)?`0 8px 24px ${data.color}40`:"none",
              }}>
              <span className="text-3xl">{data.emoji}</span>
              <span className="font-black text-white text-xl" style={{fontFamily:"'Baloo 2',cursive"}}>{data.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-3 w-full max-w-xs">
        {[{icon:"🔄",v:"∞",l:"Zadataka"},{icon:"🇭🇷",v:"HRV",l:"Kurikulum"},{icon:"🎁",v:"100%",l:"Besplatno"}].map(s=>(
          <div key={s.l} className="flex-1 flex flex-col items-center gap-1 rounded-2xl py-3"
            style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)"}}>
            <span className="text-xl">{s.icon}</span>
            <span className="text-white font-black text-sm" style={{fontFamily:"'Baloo 2',cursive"}}>{s.v}</span>
            <span className="text-white opacity-40 text-xs" style={{fontFamily:"'Nunito',sans-serif"}}>{s.l}</span>
          </div>
        ))}
      </div>

      <button onClick={handleStart}
        className="w-full max-w-xs py-4 rounded-2xl font-black text-white text-lg transition-all duration-200"
        style={{
          background: (name.trim() && selected) ? "linear-gradient(135deg,#FECA57,#FF6B6B)" : "rgba(255,255,255,0.1)",
          fontFamily:"'Baloo 2',cursive",
          opacity: (name.trim() && selected) ? 1 : 0.5,
          boxShadow: (name.trim() && selected) ? "0 8px 24px rgba(254,202,87,0.35)" : "none",
        }}>
        {!name.trim() ? "Upiši ime ↑" : !selected ? "Odaberi razred ↑" : `Kreni u avanturu! 🚀`}
      </button>
    </div>
  );
}

// ─── SCREEN: TOPIC MAP ────────────────────────────────────────────────────────
function TopicMap({grade,userName,progress,onTopic,onHome}) {
  const data=CURRICULUM[grade];
  const totalXP=Object.values(progress).reduce((a,b)=>a+(b.xp||0),0);

  return (
    <div className="flex flex-col gap-5 px-4 py-4">
      <div className="flex items-center gap-3">
        <div className="flex-1">
          <p className="text-white font-black text-xl" style={{fontFamily:"'Baloo 2',cursive"}}>
            {data.emoji} {data.name}
          </p>
          <p className="text-white opacity-50 text-sm" style={{fontFamily:"'Nunito',sans-serif"}}>
            Hej, {userName}! Odaberi poglavlje.
          </p>
        </div>
        <Pill color="#FECA57" bg="rgba(254,202,87,0.12)">⭐ {totalXP} XP</Pill>
      </div>

      <div className="rounded-2xl p-4" style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)"}}>
        <div className="flex justify-between mb-2">
          <span className="text-white text-sm opacity-60" style={{fontFamily:"'Nunito',sans-serif"}}>Ukupni napredak</span>
          <span className="text-yellow-300 text-sm font-bold" style={{fontFamily:"'Nunito',sans-serif"}}>
            {Object.values(progress).filter(p=>p.completed).length}/{data.topics.length} poglavlja
          </span>
        </div>
        <ProgressBar value={Object.values(progress).filter(p=>p.completed).length}
          max={data.topics.length} color={`linear-gradient(90deg,${data.color},#FF6B6B)`} h={6} />
      </div>

      <div className="flex flex-col gap-3">
        {data.topics.map((topic,idx)=>{
          const prog=progress[topic.id]||{};
          const done=prog.completed;
          const locked=idx>0&&!(progress[data.topics[idx-1].id]?.completed);
          return (
            <button key={topic.id} onClick={()=>!locked&&onTopic(topic)}
              className="flex items-center gap-4 rounded-2xl px-4 py-4 text-left w-full transition-all duration-200"
              style={{
                background:done?`${data.color}18`:locked?"rgba(255,255,255,0.03)":"rgba(255,255,255,0.07)",
                border:`1.5px solid ${done?data.color+"44":locked?"rgba(255,255,255,0.06)":"rgba(255,255,255,0.12)"}`,
                opacity:locked?0.4:1,
              }}>
              <div className="text-4xl w-12 flex items-center justify-center">{topic.icon}</div>
              <div className="flex-1">
                <p className="text-white font-bold text-base mb-0.5" style={{fontFamily:"'Nunito',sans-serif"}}>{topic.name}</p>
                <p className="text-white opacity-50 text-xs mb-2" style={{fontFamily:"'Nunito',sans-serif"}}>{topic.desc}</p>
                <ProgressBar value={prog.xp||0} max={50} color={data.color} h={4} />
              </div>
              <div className="flex flex-col items-center gap-1 ml-2">
                {done?<span className="text-2xl">✅</span>
                  :locked?<span className="text-2xl opacity-30">🔒</span>
                  :(prog.xp||0)>0?<span className="text-2xl">⚡</span>
                  :<span className="text-white opacity-30 text-2xl">▶️</span>}
                {!locked&&<span className="text-xs font-bold" style={{color:data.color,fontFamily:"'Nunito',sans-serif"}}>
                  {prog.xp||0}/50 XP
                </span>}
              </div>
            </button>
          );
        })}
      </div>

      {Object.values(progress).some(p=>p.completed)&&(
        <div className="rounded-2xl p-4" style={{background:"rgba(254,202,87,0.08)",border:"1px solid rgba(254,202,87,0.2)"}}>
          <p className="text-yellow-300 font-black text-sm mb-2" style={{fontFamily:"'Baloo 2',cursive"}}>🏅 Zaslužene značke</p>
          <div className="flex gap-2 flex-wrap">
            {Object.entries(progress).filter(([,p])=>p.completed).map(([id])=>{
              const t=data.topics.find(t=>t.id===id);
              return t?(<div key={id} className="flex items-center gap-1 px-3 py-1 rounded-xl"
                style={{background:"rgba(254,202,87,0.12)",border:"1px solid rgba(254,202,87,0.3)"}}>
                <span>{t.icon}</span>
                <span className="text-white text-xs font-bold" style={{fontFamily:"'Nunito',sans-serif"}}>{t.name}</span>
              </div>):null;
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── SCREEN: QUIZ ────────────────────────────────────────────────────────────
function QuizScreen({topic,grade,onFinish,existing,onHome}) {
  const data=CURRICULUM[grade];

  // Generate fresh questions on every mount (or retry)
  const generateQuestions = useCallback(()=>
    Array.from({length:TOTAL_QUESTIONS},()=>GENERATORS[topic.id]())
  ,[topic.id]);

  const [questions,setQuestions]=useState(()=>generateQuestions());
  const [qIdx,setQIdx]=useState(0);
  const [selected,setSelected]=useState(null);
  const [showResult,setShowResult]=useState(false);
  const [score,setScore]=useState(0);
  const [showHint,setShowHint]=useState(false);
  const [streak,setStreak]=useState(0);
  const [finished,setFinished]=useState(false);
  const [results,setResults]=useState([]);

  const q=questions[qIdx];
  const isCorrect=selected===q.correct;

  const handleAnswer=(i)=>{
    if(selected!==null)return;
    setSelected(i);
    const correct=i===q.correct;
    setResults(r=>[...r,correct]);
    if(correct){setScore(s=>s+1);setStreak(s=>s+1);}
    else setStreak(0);
    setTimeout(()=>setShowResult(true),500);
  };

  const handleNext=()=>{
    if(qIdx<questions.length-1){
      setQIdx(i=>i+1);setSelected(null);setShowResult(false);setShowHint(false);
    } else setFinished(true);
  };

  const handleRetry=()=>{
    setQuestions(generateQuestions()); // ← fresh random questions!
    setQIdx(0);setSelected(null);setShowResult(false);
    setShowHint(false);setScore(0);setStreak(0);
    setFinished(false);setResults([]);
  };

  if(finished){
    const pct=Math.round((score/questions.length)*100);
    const xpEarned=Math.round((score/questions.length)*50);
    const prevXP=existing?.xp||0;
    // XP = MAX of all attempts, never additive
    const newXP=Math.max(prevXP, xpEarned);
    const improved = newXP > prevXP;
    const completed=newXP>=40||pct>=80;

    return (
      <div className="flex flex-col items-center gap-6 px-4 py-6 text-center">
        <div className="text-7xl" style={{animation:"float 2s ease-in-out infinite",filter:`drop-shadow(0 0 24px ${data.color})`}}>
          {pct>=80?"🏆":pct>=60?"🌟":"💪"}
        </div>
        <div>
          <p className="text-white font-black text-3xl mb-1" style={{fontFamily:"'Baloo 2',cursive"}}>
            {pct>=80?"Izvrsno!":pct>=60?"Dobro!":"Pokušaj opet!"}
          </p>
          <p className="text-white opacity-60" style={{fontFamily:"'Nunito',sans-serif"}}>
            {score} od {questions.length} točnih odgovora
          </p>
        </div>

        <div className="flex gap-2 flex-wrap justify-center">
          {results.map((res,i)=>(
            <div key={i} className="w-10 h-10 rounded-full flex items-center justify-center font-black text-base"
              style={{background:res?"rgba(46,213,115,0.2)":"rgba(255,107,107,0.2)",
                border:`2px solid ${res?"#2ed573":"#FF6B6B"}`}}>
              {res?"✓":"✗"}
            </div>
          ))}
        </div>

        <div className="w-full rounded-2xl p-5"
          style={{background:completed?"rgba(254,202,87,0.12)":"rgba(255,255,255,0.06)",
            border:`1.5px solid ${completed?"rgba(254,202,87,0.3)":"rgba(255,255,255,0.1)"}`}}>
          <p className="text-yellow-300 font-black text-xl mb-1" style={{fontFamily:"'Baloo 2',cursive"}}>
            {improved ? `🆙 Novi rekord: ${newXP} XP!` : `⭐ Tvoj best: ${newXP} XP`}
          </p>
          {improved && prevXP > 0 && (
            <p className="text-white opacity-50 text-xs mb-2" style={{fontFamily:"'Nunito',sans-serif"}}>
              Prethodni best: {prevXP} XP → poboljšao si za {newXP - prevXP} XP!
            </p>
          )}
          {!improved && prevXP > 0 && (
            <p className="text-white opacity-50 text-xs mb-2" style={{fontFamily:"'Nunito',sans-serif"}}>
              Ovaj pokušaj: {xpEarned} XP · Tvoj best ostaje {prevXP} XP
            </p>
          )}
          <ProgressBar value={newXP} max={50} color={data.color} h={8} />
          <p className="text-white opacity-50 text-xs mt-2" style={{fontFamily:"'Nunito',sans-serif"}}>
            {newXP}/50 XP · Maksimum = sve točno = 50 XP
          </p>
          {completed&&<p className="text-yellow-300 font-bold mt-2 text-sm" style={{fontFamily:"'Nunito',sans-serif"}}>
            ✅ Poglavlje završeno! Otključano sljedeće!
          </p>}
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-3 w-full">
          {/* Retry with NEW questions */}
          <button onClick={handleRetry}
            className="w-full py-4 rounded-2xl font-black text-white text-base flex items-center justify-center gap-2 transition-all"
            style={{background:`linear-gradient(135deg,${data.color},#FF6B6B)`,fontFamily:"'Baloo 2',cursive",
              boxShadow:`0 6px 20px ${data.color}44`}}>
            🔄 Vježbaj opet — novi zadaci!
          </button>

          <div className="flex gap-3">
            <button onClick={()=>onFinish({xp:newXP,completed})}
              className="flex-1 py-3 rounded-2xl font-bold text-white transition-all text-sm"
              style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.15)",fontFamily:"'Nunito',sans-serif"}}>
              ← Poglavlja
            </button>
            <button onClick={onHome}
              className="flex-1 py-3 rounded-2xl font-bold text-white transition-all text-sm"
              style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.15)",fontFamily:"'Nunito',sans-serif"}}>
              🏠 Početna
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 px-4 py-4">
      {/* Progress header */}
      <div className="flex items-center gap-3">
        <div className="flex-1">
          <div className="flex justify-between mb-1.5">
            <span className="text-white opacity-50 text-xs" style={{fontFamily:"'Nunito',sans-serif"}}>
              {topic.icon} {topic.name}
            </span>
            <span className="text-white opacity-50 text-xs" style={{fontFamily:"'Nunito',sans-serif"}}>
              {qIdx+1} / {questions.length}
            </span>
          </div>
          <ProgressBar value={qIdx+1} max={questions.length} color={data.color} h={5} />
        </div>
        {streak>=2&&(
          <div className="px-2 py-1 rounded-xl text-xs font-bold"
            style={{background:"rgba(255,107,107,0.2)",color:"#FF6B6B",border:"1px solid rgba(255,107,107,0.3)",fontFamily:"'Nunito',sans-serif"}}>
            🔥 {streak}×
          </div>
        )}
      </div>

      {/* Question card */}
      <div className="rounded-3xl p-6 flex flex-col items-center gap-3 text-center"
        style={{background:"rgba(255,255,255,0.06)",border:"1.5px solid rgba(255,255,255,0.1)",boxShadow:"0 8px 40px rgba(0,0,0,0.3)"}}>
        <span className="px-3 py-1 rounded-full text-xs font-bold"
          style={{color:data.color,background:`${data.color}20`,fontFamily:"'Nunito',sans-serif"}}>
          {topic.icon} {topic.name}
        </span>
        <p className="text-white font-black text-2xl leading-snug"
          style={{fontFamily:"'Baloo 2',cursive",textShadow:`0 0 40px ${data.color}44`}}>
          {q.q}
        </p>
        {showHint&&(
          <div className="mt-1 px-4 py-2 rounded-xl text-sm w-full"
            style={{background:"rgba(254,202,87,0.1)",border:"1px solid rgba(254,202,87,0.25)",fontFamily:"'Nunito',sans-serif"}}>
            <span className="text-yellow-300">💡 </span>
            <span className="text-white opacity-80">{q.hint}</span>
          </div>
        )}
      </div>

      {/* 📘 Educational explanation — shown AFTER answering */}
      {selected !== null && q.edu && (
        <div className="rounded-2xl px-4 py-3 flex items-start gap-2"
          style={{background:"rgba(84,160,255,0.08)",border:"1px solid rgba(84,160,255,0.2)"}}>
          <span className="text-base mt-0.5 shrink-0">📘</span>
          <p className="text-white opacity-80 text-sm leading-relaxed" style={{fontFamily:"'Nunito',sans-serif"}}>
            {q.edu}
          </p>
        </div>
      )}

      {/* Answers */}
      <div className="grid grid-cols-2 gap-3">
        {q.answers.map((a,i)=>{
          let bg="rgba(255,255,255,0.07)",border="rgba(255,255,255,0.12)",shadow="none",badge=null;
          if(selected!==null){
            if(i===q.correct){bg="rgba(46,213,115,0.15)";border="#2ed573";shadow="0 0 20px rgba(46,213,115,0.3)";badge="✅";}
            else if(i===selected&&i!==q.correct){bg="rgba(255,107,107,0.15)";border="#FF6B6B";shadow="0 0 20px rgba(255,107,107,0.3)";badge="❌";}
          }
          return (
            <button key={i} onClick={()=>handleAnswer(i)}
              className="rounded-2xl py-5 flex flex-col items-center justify-center gap-1 font-black text-white text-xl transition-all duration-200 relative"
              style={{background:bg,border:`2px solid ${border}`,boxShadow:shadow,fontFamily:"'Baloo 2',cursive"}}>
              {badge&&<span className="text-base absolute top-2 right-3">{badge}</span>}
              {a}
            </button>
          );
        })}
      </div>

      {/* Hint or result */}
      {showResult?(
        <div className="rounded-2xl p-4 text-center"
          style={{background:isCorrect?"rgba(46,213,115,0.1)":"rgba(255,107,107,0.1)",
            border:`1.5px solid ${isCorrect?"#2ed57355":"#FF6B6B55"}`}}>
          <p className="text-white font-black text-lg mb-1" style={{fontFamily:"'Baloo 2',cursive"}}>
            {isCorrect?`🎉 Točno! ${streak>=2?`${streak}× zaredom!`:"Bravo!"}`:"😅 Nije točno!"}
          </p>
          {!isCorrect&&<p className="text-white opacity-60 text-sm mb-3" style={{fontFamily:"'Nunito',sans-serif"}}>💡 {q.hint}</p>}
          <button onClick={handleNext}
            className="px-8 py-2 rounded-xl font-bold text-white"
            style={{background:isCorrect?"#2ed573":"#FF6B6B",fontFamily:"'Nunito',sans-serif"}}>
            {qIdx<questions.length-1?"Sljedeće pitanje →":"Pogledaj rezultate 🏆"}
          </button>
        </div>
      ):(
        <button onClick={()=>setShowHint(true)}
          className="text-center py-2 text-sm hover:opacity-70 transition-all text-white"
          style={{opacity:showHint?0:0.4,fontFamily:"'Nunito',sans-serif",pointerEvents:showHint?"none":"auto"}}>
          💡 Treba mi pomoć
        </button>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen,setScreen]=useState("welcome");
  const [userName,setUserName]=useState("Učenik");
  const [grade,setGrade]=useState(null);
  const [activeTopic,setActiveTopic]=useState(null);
  const [progress,setProgress]=useState({});

  const goHome=()=>{ setScreen("welcome"); setGrade(null); setActiveTopic(null); setProgress({}); };

  const handleStart=(name,g)=>{
    setUserName(name);setGrade(g);setProgress({});setScreen("topics");
  };

  const handleTopicFinish=(result)=>{
    setProgress(prev=>({...prev,[activeTopic.id]:{xp:result.xp,completed:result.completed}}));
    setActiveTopic(null);setScreen("topics");
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;700;800;900&family=Nunito:wght@400;600;700;800&display=swap');
        @keyframes twinkle{from{opacity:.2;}to{opacity:.9;}}
        @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.15);border-radius:4px}
        input::placeholder{color:rgba(255,255,255,0.3)}
      `}</style>
      <div className="min-h-screen flex justify-center"
        style={{background:"linear-gradient(160deg,#0D0F1A 0%,#160D30 40%,#0D1A2A 100%)"}}>
        <Stars />
        <div className="relative w-full max-w-sm flex flex-col z-10" style={{minHeight:"100vh"}}>

          {/* ── TOP BAR ── */}
          <div className="flex items-center justify-between px-5 py-4 sticky top-0 z-20"
            style={{background:"rgba(13,15,26,0.85)",backdropFilter:"blur(20px)",
              borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
            <Logo onClick={goHome} />
            <div className="flex gap-2 items-center">
              {grade&&screen!=="welcome"&&(
                <Pill color={CURRICULUM[grade]?.color} bg={`${CURRICULUM[grade]?.color}18`}>
                  {CURRICULUM[grade]?.emoji} {grade}. r.
                </Pill>
              )}
              {grade&&screen!=="welcome"&&(
                <Pill color="#FECA57" bg="rgba(254,202,87,0.12)">
                  ⭐ {Object.values(progress).reduce((a,b)=>a+(b.xp||0),0)} XP
                </Pill>
              )}
              {screen!=="welcome"&&(
                <button onClick={goHome}
                  className="text-white opacity-40 hover:opacity-80 transition-all text-sm px-2 py-1 rounded-xl"
                  style={{background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.1)",fontFamily:"'Nunito',sans-serif"}}>
                  🏠
                </button>
              )}
            </div>
          </div>

          {/* ── CONTENT ── */}
          <div className="flex-1 overflow-y-auto pb-8">
            {screen==="welcome"&&<WelcomeScreen onStart={handleStart} />}
            {screen==="topics"&&grade&&(
              <TopicMap grade={grade} userName={userName} progress={progress}
                onTopic={t=>{setActiveTopic(t);setScreen("quiz");}}
                onHome={goHome} />
            )}
            {screen==="quiz"&&activeTopic&&(
              <QuizScreen topic={activeTopic} grade={grade}
                existing={progress[activeTopic.id]}
                onFinish={handleTopicFinish}
                onHome={goHome} />
            )}
          </div>
        </div>
      </div>
    </>
  );
}
